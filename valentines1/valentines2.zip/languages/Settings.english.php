<?php
// Version: 2.0.1; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Valentines by <a href="http://www.smfhacks.com" target="_blank">SMFHacks.com - SMF Mods</a';

?>