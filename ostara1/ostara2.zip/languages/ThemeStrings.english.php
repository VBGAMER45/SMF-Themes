<?php
// Version: 2.0.1; Settings


$txt['runic_copy'] = 'Ostara by <a href="http://www.smfhacks.com" target="_blank">SMFHacks.com - SMF Mods</a>';

?>