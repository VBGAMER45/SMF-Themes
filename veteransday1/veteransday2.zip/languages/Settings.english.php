<?php
// Version: 2.0.1; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Veterns Day by <a href="http://www.smfhacks.com" target="_blank">SMFHacks.com - SMF Mods</a>, images from: <a href="http://www.icons-land.com/">Icons Land</a>, <a href="http://www.jesuspaintings.com/decorative-flag/american_eagle_talit.htm">Jesus Paintings</a>, <a href="http://mitocw.udsm.ac.tz/OcwWeb/History/21H-126America-in-Depression-and-WarSpring2003/RelatedResources/detail/lec10images.htm">MIT Open CourseWare</a>.<br />  The Simpsons images are copyrighted trademarks of Fox networks, this theme is not endorsed or sponsored by fox.<br />  Captain America Image is copyrighted to Marvel Comics, this theme is not endorsed or sponsored by Marvel Comics<br />  All external images are copyrighted by there respective owners.';

?>