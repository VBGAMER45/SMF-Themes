<?php
global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = ' Thanksgiving Theme by <a href="http://www.smfhacks.com" target="_blank">SMFHacks.com - SMF Mods</a>';

?>